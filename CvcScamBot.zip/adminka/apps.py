from django.apps import AppConfig


class AdminkaConfig(AppConfig):
    name = 'adminka'
